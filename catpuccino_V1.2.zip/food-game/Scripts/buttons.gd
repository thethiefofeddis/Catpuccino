extends Node2D


func _on_start_pressed() -> void:
	SceneManager.change_scene("res://Scenes/storefront.tscn", { "pattern": "scribbles" })


func _on_settings_pressed() -> void:
	SceneManager.change_scene("res://Scenes/settings.tscn", { "pattern": "scribbles" })



func _on_credits_pressed() -> void:
	SceneManager.change_scene("res://Scenes/credits.tscn", { "pattern": "scribbles" })
