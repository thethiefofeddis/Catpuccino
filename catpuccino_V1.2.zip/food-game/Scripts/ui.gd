extends Node2D


func _on_debug_pressed() -> void:
	SceneManager.change_scene("res://Scenes/storefront.tscn", { "pattern": "scribbles" })
