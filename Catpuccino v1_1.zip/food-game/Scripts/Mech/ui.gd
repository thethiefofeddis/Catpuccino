extends Node2D

@export var drink: DrinkResource

func _on_debug_pressed() -> void:
	print(drink.drink_name+ " " + drink.description)
