extends Control

signal finished(success)

@onready var success_label: RichTextLabel = %"Succsess Label"
@onready var color_rect: ColorRect = $ColorRect
@onready var coffee: ColorRect = $"../../Background/ColorRect2/Coffee"

@export var event_duration := 1.0
@export var reaction_window := 2.5
@export var display_duration := 1.0

var tween: Tween
var success := false
var active := false
var window_open := false
var timer := 0.0
var state := 0

func _ready() -> void:
	add_to_group("QTE")

	coffee.hide()
	success_label.hide()

	set_process(true)


	await get_tree().create_timer(1.0).timeout
	start_qte()

func start_qte() -> void:
	success = false
	active = true
	window_open = false
	timer = 0.0
	state = 0

	_animation()

func _process(delta: float) -> void:
	if not active:
		return

	timer += delta

	if state == 0 and timer >= event_duration:
		window_open = true
		state = 1

	if state == 1 and timer >= event_duration + reaction_window:
		_fail()

func _input(event: InputEvent) -> void:
	if not active or success:
		return

	if not window_open:
		return

	if Input.is_action_just_pressed("click"):
		_success()

func _animation() -> void:
	var mat := color_rect.material as ShaderMaterial
	if mat == null:
		return

	tween = create_tween()
	tween.tween_method(
		func(v): mat.set_shader_parameter("value", v),
		1.0,
		0.0,
		event_duration
	)

func _success() -> void:
	success = true
	active = false
	window_open = false

	if tween:
		tween.kill()

	success_label.show()
	coffee.show()

	Items.add_item(Items.latte, 1)
	Items.print_inventory()

	emit_signal("finished", true)

	await get_tree().create_timer(display_duration).timeout
	hide()
	end_game()

func _fail() -> void:
	active = false
	window_open = false

	if tween:
		tween.kill()

	emit_signal("finished", false)
	hide()
	end_game()

func end_game():
	SceneManager.change_scene("res://Scenes/inside.tscn", { "pattern": "curtains" })
