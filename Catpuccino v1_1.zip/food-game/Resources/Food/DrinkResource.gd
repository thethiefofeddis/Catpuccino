extends Resource
class_name DrinkResource

@export var drink_name: String = ""
@export var description: String = ""
@export var price: float = 0.0
@export var prep_time: float = 0.0

@export var ingredients: Array[String] = []

@export var is_hot: bool = true

@export var icon: Texture2D
