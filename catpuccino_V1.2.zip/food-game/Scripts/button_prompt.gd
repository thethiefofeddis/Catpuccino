extends Control

func _ready() -> void:
	$".".visible = false


func _on_area_2d_body_entered(body: Player) -> void:
	$".".visible = true


func _on_area_2d_body_exited(body: Player) -> void:
	$".".visible = false

func open_menu():
		SceneManager.change_scene("res://Scenes/coffee_machine_game.tscn", { "pattern": "scribbles" })


func _input(event: InputEvent) -> void:
		if Input.is_action_just_pressed("Game Open") and $".".visible:
			open_menu()
