extends Node2D


func _on_start_pressed() -> void:
	SceneManager.change_scene("res://Scenes/Outside/storefront.tscn", { "pattern": "scribbles" })


func _on_settings_pressed() -> void:
	SceneManager.change_scene("res://Scenes/Ui and Menus/settings.tscn", { "pattern": "scribbles" })



func _on_credits_pressed() -> void:
	SceneManager.change_scene("res://Scenes/Ui and Menus/credits.tscn", { "pattern": "scribbles" })
