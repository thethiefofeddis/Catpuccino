extends PathFollow2D

@export var window_spot = 0.22
@export var speed = 0.2
@export var start_point = 0.00

@onready var ani: AnimatedSprite2D = $CharacterBody2D/Ani
@onready var latte = preload("res://Resources/Food/Latte.tres")
@onready var test1 = preload("res://Resources/Food/Test1.tres")
@onready var test2 = preload("res://Resources/Food/Test2.tres")

var drinks: Array[DrinkResource] = []

var moving = true
var has_stopped_at_window = false

func _ready() -> void:
	moving = true
	ani.play("Debug")
	drinks = [latte, test1, test2]
	



func _process(delta: float) -> void:
	if moving:
		progress_ratio += delta * speed
		
		if not has_stopped_at_window and progress_ratio >= window_spot:
			progress_ratio = window_spot
			order_drink()
			moving = false
			has_stopped_at_window = true
		
		if has_stopped_at_window and progress_ratio < 0.05:
			has_stopped_at_window = false

func _on_food_given_pressed() -> void:
	if Items.inventory.is_empty():
		no_food()
	else:
		food_in_inv()

func order_drink():
	if drinks.is_empty():
		print("No drinks available!")
		return

	var drink = drinks[randi() % drinks.size()]

	print("Ordered: ", drink.drink_name)
	print("Price: $", drink.price)
	print("Description: ", drink.description)

	for ingredient in drink.ingredients:
		print("- ", ingredient)

func no_food():
	moving = false
	print ("You have no food!")

func food_in_inv():
	moving = true
	Items.remove_item(latte, 1)
	print ("Food Given, Enjoy Friend!")
