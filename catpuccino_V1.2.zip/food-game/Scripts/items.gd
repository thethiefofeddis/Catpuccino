extends Control

@onready var latte = preload("res://Resources/Food/Latte.tres")
@onready var test1 = preload("res://Resources/Food/Test1.tres")
@onready var test2 = preload("res://Resources/Food/Test2.tres")

var inventory: Dictionary = {}

func add_item(item, amount := 1):
	if item == null:
		return
	
	if not item is Resource:
		print("Rejected invalid inventory item:", item)
		return

	if inventory.has(item):
		inventory[item] += amount
	else:
		inventory[item] = amount


func remove_item(item, amount := 1):
	if not inventory.has(item):
		return

	inventory[item] -= amount

	if inventory[item] <= 0:
		inventory.erase(item)


func get_amount(item):
	return inventory.get(item, 0)


func has_item(item, amount := 1):
	return get_amount(item) >= amount


func print_inventory():
	for item in inventory.keys():

		if item == null:
			continue

		if not item is Resource:
			print("Invalid item in inventory:", item)
			continue

		if "drink_name" in item:
			print(item.drink_name, " x ", inventory[item])
		else:
			print(item.resource_path, " x ", inventory[item])
