extends Control

@onready var timer: Timer = $Timer
const QTE = preload("res://Scenes/qte.tscn")

var key_list = [
	{"key_string": "click"}
]

var count := 0
var max_clicks := 1

func _ready() -> void:
	timer.start()

func _on_timer_timeout() -> void:
	print("QTE Failed!")
	queue_free()

func _input(event):
	if event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			count += 1
			print("Clicks: ", count)

			if count >= max_clicks:
				success()

func success():
	timer.stop()
	print("QTE Success!")
	queue_free()
