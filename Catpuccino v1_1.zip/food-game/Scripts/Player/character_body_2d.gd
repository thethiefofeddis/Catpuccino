extends CharacterBody2D

@export var speed = 300.0
@onready var sprite = $AnimatedSprite2D

func _physics_process(_delta):
	var direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	
	if direction.x != 0 and direction.y != 0:
		direction.y = 0 
	
	if direction:
		velocity = direction * speed
	else:
		velocity = velocity.move_toward(Vector2.ZERO, speed)

	move_and_slide()
	update_animations(direction)

func update_animations(direction):
	if direction != Vector2.ZERO:
		if direction.y < 0:
			sprite.play("Debug")
		else:
			sprite.play("Debug")
		
		if direction.x != 0:
			sprite.flip_h = (direction.x < 0)
	else:
		sprite.play("Debug")
